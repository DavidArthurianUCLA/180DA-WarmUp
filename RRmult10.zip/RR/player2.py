import asyncio
import cv2 as cv
import numpy as np
import websockets
import json
import base64

# Define the screen dimensions (these should match the server's screen dimensions)
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800

async def send_red_centroid_data(websocket, cap):
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            continue

        frame = cv.flip(frame, 1)
        red_centroid, frame_with_boxes = find_red_objects(frame)
        cv.imshow('Video Feed', frame_with_boxes)
        if cv.waitKey(1) & 0xFF == ord('q'):
            break

        if red_centroid:
            json_data = json.dumps({"centroid2": red_centroid})
            await websocket.send(json_data)
            await asyncio.sleep(0.05)

    cap.release()
    cv.destroyAllWindows()

async def receive_screen_data(websocket):
    while True:
        screen_data = await websocket.recv()
        img_data = base64.b64decode(screen_data)
        np_arr = np.frombuffer(img_data, np.uint8)
        img = cv.imdecode(np_arr, cv.IMREAD_COLOR)

        img = cv.resize(img, (SCREEN_WIDTH, SCREEN_HEIGHT))  # Resize to the original screen size
        cv.imshow('Remote Screen', img)
        if cv.waitKey(1) & 0xFF == ord('q'):
            break

    cv.destroyAllWindows()

async def video_client():
    uri = "ws://172.26.57.196:8765"
    cap = cv.VideoCapture(0)

    async with websockets.connect(uri) as websocket:
        # Send identification message
        await websocket.send("python_client")
        
        # Start tasks for sending centroid data and receiving screen data
        send_task = asyncio.create_task(send_red_centroid_data(websocket, cap))
        receive_task = asyncio.create_task(receive_screen_data(websocket))

        await asyncio.gather(send_task, receive_task)

def find_red_objects(frame):
    hsv = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    # Define the range for red color in HSV
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([180, 255, 255])
    # Create masks for red color
    red_mask1 = cv.inRange(hsv, lower_red1, upper_red1)
    red_mask2 = cv.inRange(hsv, lower_red2, upper_red2)
    red_mask = cv.bitwise_or(red_mask1, red_mask2)
    return process_color(frame, red_mask, (0, 0, 255))

def process_color(frame, mask, color):
    contours, _ = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    centroid = None
    if contours:
        c = max(contours, key=cv.contourArea)
        x, y, w, h = cv.boundingRect(c)
        centroid = [x + w // 2, y + h // 2]
        cv.rectangle(frame, (x, y), (x + w, y + h), color, 2)
    return centroid, frame

asyncio.run(video_client())
