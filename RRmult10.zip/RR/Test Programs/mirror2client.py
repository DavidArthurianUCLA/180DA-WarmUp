import asyncio
import cv2 as cv
import numpy as np
import websockets
import json
import base64
from PIL import Image
from io import BytesIO

async def video_client():
    uri = "ws://172.26.56.178:8765"  # Ensure this matches your server URI
    screen_uri = "ws://172.26.56.178:8766"  # URI for screen mirroring

    cap = cv.VideoCapture(0)  # Ensure the correct device index is used

    async with websockets.connect(uri) as websocket, websockets.connect(screen_uri) as screen_websocket:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("Failed to grab frame")
                continue

            # Flip the frame horizontally
            frame = cv.flip(frame, 1)

            red_centroid, frame_with_boxes = find_objects(frame)
            cv.imshow('Video Feed', frame_with_boxes)

            if cv.waitKey(1) & 0xFF == ord('q'):
                break

            if red_centroid:
                json_data = json.dumps({"centroid": red_centroid})
                await websocket.send(json_data)
                await asyncio.sleep(0.05)  # Prevents spamming the server too quickly

            # Receive and display screen capture
            try:
                screen_message = await screen_websocket.recv()
                screen_data = json.loads(screen_message)
                if 'screen' in screen_data:
                    image_data = base64.b64decode(screen_data['screen'])
                    image = Image.open(BytesIO(image_data))
                    screen_frame = np.array(image)
                    screen_frame = cv.cvtColor(screen_frame, cv.COLOR_RGB2BGR)
                    cv.imshow('Screen Mirror', screen_frame)
            except Exception as e:
                print(f"Failed to receive screen capture: {e}")

    cap.release()
    cv.destroyAllWindows()

def find_objects(frame):
    hsv = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    
    # Red can be in two ranges in HSV
    lower_red1 = np.array([0, 100, 100])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([160, 100, 100])
    upper_red2 = np.array([180, 255, 255])
    
    # Create masks for the two red ranges
    red_mask1 = cv.inRange(hsv, lower_red1, upper_red1)
    red_mask2 = cv.inRange(hsv, lower_red2, upper_red2)
    
    # Combine the masks
    red_mask = cv.bitwise_or(red_mask1, red_mask2)
    
    return process_color(frame, red_mask, (0, 0, 255))

def process_color(frame, mask, color):
    contours, _ = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    centroid = None
    if contours:
        c = max(contours, key=cv.contourArea)
        x, y, w, h = cv.boundingRect(c)
        centroid = [x + w // 2, y + h // 2]
        cv.rectangle(frame, (x, y), (x + w, y + h), color, 2)
    return centroid, frame

asyncio.run(video_client())
