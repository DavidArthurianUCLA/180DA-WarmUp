import asyncio
import websockets
import pygame
import json
import sys
import io
import zlib
from PIL import Image

# Initialize Pygame
pygame.init()
SCREEN_WIDTH, SCREEN_HEIGHT = 1400, 800
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Object Tracking")

# Load images
background = pygame.image.load("background.png").convert()
crosshair_image = pygame.image.load("crosshair.png").convert_alpha()
crosshair_image = pygame.transform.scale(crosshair_image, (50, 50))

# Queue for centroids
centroid_queue = asyncio.Queue()

clients = set()

async def handle_websocket(websocket, path):
    clients.add(websocket)
    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                if 'centroid' in data:
                    await centroid_queue.put(data['centroid'])
                else:
                    print("Received non-centroid JSON message:", data)
            except json.JSONDecodeError:
                print("Received non-JSON or improperly formatted message:", message)
    except websockets.exceptions.ConnectionClosed:
        print("WebSocket connection closed")
    finally:
        clients.remove(websocket)

async def update_screen(run_event):
    try:
        while run_event.is_set():
            screen.blit(background, (0, 0))  # Always draw the background
            if not centroid_queue.empty():
                centroid = await centroid_queue.get()
                x, y = centroid
                x = x * SCREEN_WIDTH // 640
                y = y * SCREEN_HEIGHT // 480
                screen.blit(crosshair_image, (x - crosshair_image.get_width() // 2, y - crosshair_image.get_height() // 2))
            pygame.display.flip()

            # Capture the screen
            screenshot = pygame.surfarray.array3d(pygame.display.get_surface())
            screenshot = screenshot.transpose([1, 0, 2])  # Transpose the array for PIL
            image = Image.fromarray(screenshot)

            # Reduce the image resolution
            image = image.resize((SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2), Image.LANCZOS)

            # Convert image to bytes
            img_byte_arr = io.BytesIO()
            image.save(img_byte_arr, format='PNG')
            img_byte_arr = img_byte_arr.getvalue()

            # Compress the image data
            compressed_data = zlib.compress(img_byte_arr)

            # Send the compressed image data to all connected clients
            disconnected_clients = []
            for client in clients:
                try:
                    await client.send(compressed_data)
                except websockets.exceptions.ConnectionClosed:
                    print("A client disconnected.")
                    disconnected_clients.append(client)

            # Remove disconnected clients from the set
            for client in disconnected_clients:
                clients.remove(client)

            await asyncio.sleep(0.016)  # Manage frame delay
    finally:
        pygame.quit()

def check_pygame_events(run_event):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run_event.clear()

async def main():
    run_event = asyncio.Event()
    run_event.set()
    server = await websockets.serve(handle_websocket, "172.30.72.247", 8765, max_size=2**20)

    screen_update_task = asyncio.create_task(update_screen(run_event))
    try:
        while run_event.is_set():
            check_pygame_events(run_event)
            await asyncio.sleep(0.1)  # Check for Pygame events at an interval
    except KeyboardInterrupt:
        print("Shutdown initiated.")
    finally:
        run_event.clear()
        screen_update_task.cancel()
        try:
            await screen_update_task
        except asyncio.CancelledError:
            print("Screen update task cancelled.")
        server.close()
        await server.wait_closed()

asyncio.run(main())
