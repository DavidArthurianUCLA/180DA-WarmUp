import asyncio
import cv2
import websockets
import base64
import numpy as np

async def video_client():
    uri = "ws://localhost:8765"
    
    async with websockets.connect(uri) as websocket:
        while True:
            data = await websocket.recv()
            jpg_original = base64.b64decode(data)
            jpg_as_np = np.frombuffer(jpg_original, dtype=np.uint8)
            img = cv2.imdecode(jpg_as_np, flags=1)

            cv2.imshow('Video feed', img)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cv2.destroyAllWindows()

asyncio.get_event_loop().run_until_complete(video_client())
