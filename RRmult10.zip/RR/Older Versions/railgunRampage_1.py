# Import standard libraries
import random
import sys
import time
import os

# Import GUI library
import pygame
from pygame.locals import (
    RLEACCEL, K_UP, K_DOWN, K_LEFT, K_RIGHT, K_ESCAPE, 
    KEYDOWN, K_f, K_n, QUIT, K_m)

# Import libraries for computer vision
import cv2
import numpy as np

# Import libraries for asynchronous operations and web sockets
import asyncio
import websockets
import threading
from queue import Queue

# Import library for speech recognition
import speech_recognition as sr

# Initialize PyGame and mixer for sound effects
pygame.init()
pygame.mixer.init()  # Initialize the mixer module

# Screen and health bar constants
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800
HEALTH_BAR_WIDTH = 600
HEALTH_BAR_HEIGHT = 25
HEALTH_BAR_OUTLINE_WIDTH = 5
HEALTH_BAR_OUTLINE_COLOR = (255, 0, 0)
HEALTH_BAR_POSITION = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50)

# Player health and ammo management
player_health = 100  # Initial player health
max_player_health = 100  # Maximum player health
max_shots = 5  # Maximum shots before needing a reload
current_shots = max_shots  # Current available shots

# Sound effects loading
shoot_sound = pygame.mixer.Sound('shoot.mp3')
enemy_dying_sound = pygame.mixer.Sound('enemyDying.mp3')
reload_sound = pygame.mixer.Sound('reload.mp3')
health_lost_sound = pygame.mixer.Sound('healthLoss.mp3')
no_ammo_sound = pygame.mixer.Sound('no_ammo.mp3')

# Adjust sound volume
shoot_sound.set_volume(0.5)
enemy_dying_sound.set_volume(1.0)
reload_sound.set_volume(1.0)
health_lost_sound.set_volume(2.0)
no_ammo_sound.set_volume(1.0)

# Setup for frame rate management
clock = pygame.time.Clock()

# Create the main game screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Font setup for drawing text
default_font = pygame.font.Font(None, 36)

# Camera initialization for object localization
cap = cv2.VideoCapture(0)

# Global variables
command_queue = Queue()  # Queue for command handling
recognizer = sr.Recognizer()  # For speech recognition
microphone = sr.Microphone()  # Microphone setup for speech recognition
player = None  # Placeholder for player object, to be defined in game logic
# switch_to_settings = False  # Flag for switching to settings, used in game logic
is_paused = False  # Flag to check if the game is paused

# Web Socket function
async def handle_shoot_reload(websocket, path):
    global current_shots, score, enemies, player
    async for message in websocket:
        command_queue.put(message)  # Put the received command into the queue
        if message == "shoot":
            if current_shots > 0:
                shoot_sound.play()
                current_shots -= 1
            else:
                no_ammo_sound.play()
        elif message == "reload":
            reload_sound.play()
            current_shots = max_shots

def start_websocket_server():
    global loop  # Declare loop as global
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    start_server = websockets.serve(handle_shoot_reload, "192.168.1.46", 8765)
    loop.run_until_complete(start_server)
    loop.run_forever()

# Run the WebSocket server in a separate thread
websocket_thread = threading.Thread(target=start_websocket_server, name="WebSocketThread")
websocket_thread.start()

def recognize_speech_from_mic(recognizer, microphone):
    """Recognizes speech from the microphone and returns the transcription."""
    # Check that the recognizer and microphone arguments are appropriate types
    if not isinstance(recognizer, sr.Recognizer):
        raise TypeError("`recognizer` must be `Recognizer` instance")

    if not isinstance(microphone, sr.Microphone):
        raise TypeError("`microphone` must be `Microphone` instance")

    with microphone as source:
        recognizer.adjust_for_ambient_noise(source)  # Adjust for ambient noise
        print("Listening...")  # Signal to the user to start speaking
        try:
            audio = recognizer.listen(source, timeout=5)  # Listen for the first phrase
        except sr.WaitTimeoutError:  # Handling cases where no speech is detected within the timeout
            print("Listening timed out while waiting for speech")
            return ""  # Return an empty string to indicate failure

    # Recognize speech using Google Speech Recognition
    try:
        transcription = recognizer.recognize_google(audio)
        print(f"Transcription: {transcription}")  # Optional: Print the recognized text
        return transcription  # Return the recognized text
    except sr.RequestError:
        # API was unreachable or unresponsive
        print("Speech Recognition service is unavailable")
    except sr.UnknownValueError:
        # Speech was unintelligible
        print("Unable to recognize speech")

    return ""  # Return an empty string if recognition fails


def find_blue_object(frame):
    # Apply Gaussian Blur to reduce noise and improve color detection
    blurred_frame = cv2.GaussianBlur(frame, (5, 5), 0)

    # Convert the blurred frame to HSV color space
    hsv = cv2.cvtColor(blurred_frame, cv2.COLOR_BGR2HSV)

    # Adjust the range for blue color to be more inclusive and robust
    lower_blue = np.array([90, 100, 100])
    upper_blue = np.array([150, 255, 255])

    # Threshold the HSV image to get only blue colors
    mask = cv2.inRange(hsv, lower_blue, upper_blue)

    # Optional: Apply additional morphological operations like opening to remove small objects or noise
    kernel = np.ones((5, 5), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

    # Find contours in the mask
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    # Filter contours by area (if needed)
    filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 500]  # Adjust 500 to your specific needs

    # Proceed only if at least one contour was found
    if filtered_contours:
        # Find the largest contour among the filtered ones, assuming it's the blue object
        largest_contour = max(filtered_contours, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(largest_contour)

        # Draw a bounding box around the largest contour
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

        centroid = (x + w // 2, y + h // 2)
        return centroid
    return None

def draw_text(text, position, font_size=36, color=(255, 0, 0), highlight_color=(50, 50, 50)):
    # Set up the font with the specified font size
    font = pygame.font.Font(None, font_size)

    # Create the main text surface in red
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=position)

    # Create a 'highlight' or 'shadow' for the text in dark grey, slightly offset
    highlight_surface = font.render(text, True, highlight_color)
    highlight_rect = highlight_surface.get_rect(center=(position[0]+2, position[1]+2))  # Adjust the offset values as needed

    # Blit the highlight first, then the main text on top
    screen.blit(highlight_surface, highlight_rect)
    screen.blit(text_surface, text_rect)

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super(Player, self).__init__()
        # Load the image with transparency preserved
        self.surf = pygame.image.load("crosshair.png").convert_alpha()
        # Scale the image to the desired size
        self.surf = pygame.transform.scale(self.surf, (100, 100)) 
        self.rect = self.surf.get_rect()

    def update(self):
        # Capture the current frame
        ret, frame = cap.read()

        if not ret:
            return  # If frame not captured successfully, skip this iteration

        # Find the blue object in the frame
        centroid = find_blue_object(frame)

        if centroid:
            # Invert the x-coordinate movement
            inverted_x = frame.shape[1] - centroid[0]
            # Adjust the player's position on screen based on the inverted x-coordinate
            self.rect.center = (inverted_x * SCREEN_WIDTH // frame.shape[1], centroid[1] * SCREEN_HEIGHT // frame.shape[0])
        
        # Display the frame in a separate OpenCV window
        cv2.imshow("Camera Output", frame)
        cv2.waitKey(1)  # Refresh the display window at short intervals

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super(Enemy, self).__init__()
        # Load the image, ensuring the use of the alpha channel for transparency
        self.original_surf = pygame.image.load("enemy.png").convert_alpha()
        # Scale the image to the desired size (e.g., 50x50 pixels)
        self.surf = pygame.transform.scale(self.original_surf, (200, 200))
        self.rect = self.surf.get_rect(
            center=(
                random.randint(SCREEN_WIDTH + 20, SCREEN_WIDTH + 100),
                random.randint(0, SCREEN_HEIGHT),
            )
        )
        self.speed = random.randint(5, 10)

    def update(self):
        self.rect.move_ip(-self.speed, 0)
        if self.rect.right < 0:
            global player_health
            player_health -= 10  # Decrease health by 10%
            if player_health <= 0:
                player_health = 0  # Ensure health doesn't go below 0
            self.kill()

def quit_game():
    global websocket_thread, loop  # Make sure to declare these as global at the point of their creation
    
    # Check if the WebSocket server's event loop is running and stop it
    if loop.is_running():
        loop.call_soon_threadsafe(loop.stop)  # Gracefully stop the loop
        while loop.is_running():
            time.sleep(0.1)  # Wait a bit for the event loop to stop

    # Close the loop after stopping it
    loop.close()
    
    # Ensure the WebSocket thread is joined
    if websocket_thread.is_alive():
        websocket_thread.join()
    
    cap.release()  # Release the camera
    cv2.destroyAllWindows()  # Close all OpenCV windows
    pygame.quit()  # Quit pygame
    sys.exit()  # Exit the script

def pause_menu():
    global mic_available  # Assuming mic_available is declared globally at the top of your script
    mic_available = True  # Ensure the microphone is available when entering the pause menu

    pygame.mixer.music.pause()  # Pause the in-game music

    paused = True
    while paused:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # Return to main menu
                    paused = False
                    main_menu()  # This will handle playing the main menu music
                elif event.key == pygame.K_p:  # Resume the game
                    pygame.mixer.music.unpause()  # Unpause the in-game music
                    paused = False
                elif event.key == pygame.K_m and mic_available:
                    mic_available = False  # Temporarily disable the microphone to prevent re-entry
                    
                    # Activate the microphone and listen for speech
                    speech_command = recognize_speech_from_mic(recognizer, microphone)
                    if speech_command.lower() == "main menu":
                        paused = False
                        main_menu()  # Return to the main menu
                    elif speech_command.lower() == "resume":
                        pygame.mixer.music.unpause()  # Unpause the in-game music
                        paused = False
                    
                    mic_available = True  # Re-enable the microphone after processing
                    
            elif event.type == pygame.QUIT:
                quit_game()

        screen.fill((0, 0, 0))
        draw_text("PAUSED", (SCREEN_WIDTH/2, SCREEN_HEIGHT/8), font_size=120)
        draw_text("MAIN MENU (ESC)", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2.5), font_size=80)
        draw_text("RESUME (P)", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2), font_size=80)

        pygame.display.flip()
        clock.tick(30)

def settings_menu():
    global mic_available  # Ensure this is declared at the top of your script
    mic_available = True  # Make sure the microphone is available when entering settings

    in_settings = True
    while in_settings:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # Return to main menu
                    in_settings = False
                elif event.key == pygame.K_m and mic_available:
                    # Prevent further activation until this cycle is complete
                    mic_available = False

                    # Activate the microphone and listen for speech
                    speech_command = recognize_speech_from_mic(recognizer, microphone)
                    if speech_command.lower() == "return":
                        in_settings = False  # Exit the settings menu

                    # After processing the command, allow microphone activation again
                    mic_available = True

            elif event.type == pygame.QUIT:
                quit_game()

        screen.fill((0, 0, 0))
        draw_text("SETTINGS", (SCREEN_WIDTH/2, SCREEN_HEIGHT/8), font_size=120)
        draw_text("MAIN MENU (ESC)", (SCREEN_WIDTH/2, SCREEN_HEIGHT/2.5), font_size=80)

        pygame.display.flip()
        clock.tick(30)


def game_loop(restart=False):
   global player_health, score, current_shots, max_shots, enemies, all_sprites, running, mic_available

   player = Player()
   
   if restart:
        # Reset necessary variables for a new game
        player_health = 100  # Reset player's health
        score = 0  # Reset score
        current_shots = max_shots  # Reset ammunition
        enemies.empty()  # Remove all enemy sprites
        all_sprites.empty()  # Remove all sprites
        all_sprites.add(player)  # Add the player sprite back
        pygame.mixer.music.load('in_game_music.mp3')  # Reload in-game music
        pygame.mixer.music.set_volume(0.2)
        pygame.mixer.music.play(-1)

   if not restart:
        # Play in-game music only if not restarting the game
        pygame.mixer.music.load('in_game_music.mp3')
        pygame.mixer.music.set_volume(0.2)  # music volume
        pygame.mixer.music.play(-1)  # Play the music indefinitely

   background = pygame.image.load("background.png").convert()
   background = pygame.transform.scale(background, (1900, 1000))

   # player = Player()

   enemies = pygame.sprite.Group()
   all_sprites = pygame.sprite.Group()
   all_sprites.add(player)

   ADDENEMY = pygame.USEREVENT + 1
   spawn_interval = 2500  # Adjust this value as needed to decrease spawn frequency
   score = 0
   running = True
   game_start_time = pygame.time.get_ticks()
   spawn_delay_passed = False

   mic_available = True

   while running:
        current_time = pygame.time.get_ticks()
        if not spawn_delay_passed and current_time - game_start_time > 2000: # Ten sec delay when starting the game
            pygame.time.set_timer(ADDENEMY, spawn_interval)
            spawn_delay_passed = True

        if is_paused:
            pause_menu()  # Display the pause menu
            #is_paused = False
            continue  # Skip the rest of the game loop

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pause_menu()
                elif event.key == pygame.K_UP: # UNCOMMENT TO TEST GAME OVER SCREEN
                    running = False
                    game_over_screen(score)
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_m and mic_available:
                    mic_available = False  # Prevent multiple activations

                    # Activate the microphone and listen for speech
                    speech_command = recognize_speech_from_mic(recognizer, microphone)
                    if speech_command.lower() == "stop":
                        pause_menu()  # Call your pause menu
                        pygame.mixer.music.unpause()  # Ensure music playback resumes if coming back from pause
                mic_available = True  # Re-enable microphone after processing    
            elif event.type == pygame.QUIT:
                running = False
            elif event.type == ADDENEMY and spawn_delay_passed:
                new_enemy = Enemy()
                enemies.add(new_enemy)
                all_sprites.add(new_enemy)

        # Process commands from the queue
        while not command_queue.empty():
            command = command_queue.get_nowait()  # Retrieve the next command without blocking
            if command == "shoot":
                if current_shots > 0:
                    killed_enemies = pygame.sprite.spritecollide(player, enemies, dokill=True)
                    if killed_enemies:
                        for _ in killed_enemies:
                            score += 100 * len(killed_enemies)  # Update the score based on the number of enemies killed

        #asyncio.get_event_loop().run_until_complete(asyncio.sleep(0))
        player.update()

        for enemy in enemies:
            enemy.update()
            if enemy.rect.right < 0:  # Enemy has passed the left edge
                health_lost_sound.play()
                enemy.kill()
                player_health -= 10  # Decrease health by 10%

        # Check player health after updating all enemies
        if player_health <= 0:
            game_over_screen(score)  # Call game over screen when health depletes
            break  # Exit the game loop

        screen.blit(background, (0, 0))
        draw_health_bar(screen, player_health, HEALTH_BAR_POSITION)
        for entity in all_sprites:
            screen.blit(entity.surf, entity.rect)

        draw_text("WALL HEALTH", (HEALTH_BAR_POSITION[0], HEALTH_BAR_POSITION[1] - 40), font_size=60)
        mag_text = f"BLASTS: {current_shots}/{max_shots}"
        draw_text(mag_text, (SCREEN_WIDTH - 220, SCREEN_HEIGHT - 30), font_size=60)
        draw_text(f"SCORE: {score}", (SCREEN_WIDTH * 0.5, SCREEN_HEIGHT * 0.05), font_size=80)

        pygame.display.flip()
        clock.tick(30)

def draw_health_bar(screen, health, position):
    # Define the position and size of the health bar
    health_bar_x = position[0] - (HEALTH_BAR_WIDTH // 2)
    health_bar_y = position[1]
    health_bar_filled_width = int((health / max_player_health) * HEALTH_BAR_WIDTH)

    # Draw the health bar outline
    outline_rect = pygame.Rect(health_bar_x, health_bar_y, HEALTH_BAR_WIDTH, HEALTH_BAR_HEIGHT)
    pygame.draw.rect(screen, HEALTH_BAR_OUTLINE_COLOR, outline_rect, HEALTH_BAR_OUTLINE_WIDTH)

    # Draw the filled part of the health bar
    filled_rect = pygame.Rect(health_bar_x, health_bar_y, health_bar_filled_width, HEALTH_BAR_HEIGHT)
    pygame.draw.rect(screen, (255, 0, 0), filled_rect)

def game_over_screen(score):
    global mic_available  # Ensure mic_available is declared globally at the top of your script
    mic_available = True  # Ensure the microphone is available when entering the game over screen

    while True:  # Using 'True' for clarity
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    game_loop(restart=True)  # Restart the game
                    return  # Exit the game over screen after restarting the game
                elif event.key == pygame.K_ESCAPE:
                    main_menu()  # Return to the main menu
                    return  # Exit the game over screen after going to the main menu
                elif event.key == pygame.K_m and mic_available:
                    mic_available = False  # Temporarily disable the microphone to prevent re-entry

                    # Activate the microphone and listen for speech
                    speech_command = recognize_speech_from_mic(recognizer, microphone)
                    if speech_command.lower() == "restart":
                        game_loop(restart=True)  # Restart the game
                        return  # Exit the game over screen after restarting the game
                    elif speech_command.lower() == "main menu":
                        main_menu()  # Return to the main menu
                        return  # Exit the game over screen after going to the main menu

                    mic_available = True  # Re-enable the microphone after processing

            elif event.type == pygame.QUIT:
                quit_game()

        screen.fill((0, 0, 0))  # Clear the screen
        draw_text("GAME OVER", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 8), font_size=120, color=(255, 0, 0))
        draw_text(f"YOUR SCORE: {score}", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 4), font_size=120)
        draw_text("PLAY AGAIN (P)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.3), font_size=80)
        draw_text("MAIN MENU (ESC)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), font_size=80)

        pygame.display.flip()  # Update the screen
        clock.tick(30)  # Maintain a steady framerate


def main_menu():
    main_menu_background = pygame.image.load("main_menu_background.png").convert()
    main_menu_background = pygame.transform.scale(main_menu_background, (SCREEN_WIDTH, SCREEN_HEIGHT))

    pygame.mixer.music.load('main_menu_music.mp3')
    pygame.mixer.music.play(-1)

    menu_running = True
    while menu_running:
        screen.blit(main_menu_background, (0, 0))
        draw_text("RAILGUN RAMPAGE", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 14), font_size=140)
        draw_text("PLAY (P)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.7), font_size=80)
        draw_text("SETTINGS (S)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2.3), font_size=80)
        draw_text("QUIT (ESC)", (SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2), font_size=80)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    pygame.mixer.music.stop()
                    game_loop()
                    pygame.mixer.music.play(-1)
                elif event.key == pygame.K_s:
                    settings_menu()
                elif event.key == pygame.K_m:
                    # Activate the microphone and listen for speech
                    speech_command = recognize_speech_from_mic(recognizer, microphone)
                    if speech_command.lower() == "play":
                        pygame.mixer.music.stop()
                        game_loop()
                        pygame.mixer.music.play(-1)
                    elif speech_command.lower() == "settings":
                        settings_menu()
                    elif speech_command.lower() == "quit":
                        quit_game()
                elif event.key == pygame.K_ESCAPE:  # Quitting the main menu
                    quit_game()
            elif event.type == pygame.QUIT:
                quit_game()

if __name__ == '__main__':
    main_menu()

# Release the camera when the game is closed
#cap.release()
#cv2.destroyAllWindows()