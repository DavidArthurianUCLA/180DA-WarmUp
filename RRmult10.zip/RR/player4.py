import asyncio
import cv2 as cv
import numpy as np
import websockets
import json
import base64

# Define the screen dimensions (these should match the server's screen dimensions)
SCREEN_WIDTH = 1400
SCREEN_HEIGHT = 800

async def send_yellow_centroid_data(websocket, cap):
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Failed to grab frame")
            continue

        # Flip the frame horizontally
        frame = cv.flip(frame, 1)

        yellow_centroid, frame_with_boxes = find_yellow_objects(frame)
        cv.imshow('Video Feed', frame_with_boxes)
        if cv.waitKey(1) & 0xFF == ord('q'):
            break

        if yellow_centroid:
            json_data = json.dumps({"centroid4": yellow_centroid})
            await websocket.send(json_data)
            await asyncio.sleep(0.05)  # Prevents spamming the server too quickly

    cap.release()
    cv.destroyAllWindows()

async def receive_screen_data(websocket):
    while True:
        screen_data = await websocket.recv()
        img_data = base64.b64decode(screen_data)
        np_arr = np.frombuffer(img_data, np.uint8)
        img = cv.imdecode(np_arr, cv.IMREAD_COLOR)

        # Resize to the original screen size for clarity
        img = cv.resize(img, (SCREEN_WIDTH, SCREEN_HEIGHT))
        cv.imshow('Remote Screen', img)
        if cv.waitKey(1) & 0xFF == ord('q'):
            break

    cv.destroyAllWindows()

async def video_client():
    uri = "ws://172.26.57.196:8765"
    cap = cv.VideoCapture(0)

    async with websockets.connect(uri) as websocket:
        await websocket.send("python_client")
        send_task = asyncio.create_task(send_yellow_centroid_data(websocket, cap))
        receive_task = asyncio.create_task(receive_screen_data(websocket))

        await asyncio.gather(send_task, receive_task)

def find_yellow_objects(frame):
    hsv = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    lower_yellow = np.array([20, 100, 100])
    upper_yellow = np.array([30, 255, 255])
    yellow_mask = cv.inRange(hsv, lower_yellow, upper_yellow)
    return process_color(frame, yellow_mask, (0, 255, 255))

def process_color(frame, mask, color):
    contours, _ = cv.findContours(mask, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    centroid = None
    if contours:
        c = max(contours, key=cv.contourArea)
        x, y, w, h = cv.boundingRect(c)
        centroid = [x + w // 2, y + h // 2]
        cv.rectangle(frame, (x, y), (x + w, y + h), color, 2)
    return centroid, frame

asyncio.run(video_client())
